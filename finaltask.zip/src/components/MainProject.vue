<template>
    <div>
      <div class="s21container">
        <img src="../assets/img/s2/ProjectBanner.png">
    </div>
    
      <div class="s22container">
          <div class="s22container__text">
              <div class="s22container__text__up">
              <span class="s22container__text__up__title">Наш проект</span></div>
              <router-link class="header__right__link" to="/"><span class="s22container__text__subtitle">Домой 
              </span></router-link> 
              <router-link class="header__right__link" to="/projectdetails"><span class="s22container__text__subtitle">Детали
              </span></router-link> 
          </div>
      </div>
 
      
      <div class="tags">
        <button v-for="tag in uniqueTags" :key="tag" @click="selectTag(tag)" :class="{ active: selectedTag === tag }">
          {{ tag }}
        </button>
      </div>
      
      <div class="s4container">
        <div v-for="item in filteredItems" :key="item.id" class="s4container__link">
         <img class="s4container__link__img" :src="item.image" alt="Item image" />
          <div class="s4container__link__subimg__text"><router-link class="header__right__link" to="/projectdetails">
            <span class="s4container__link__subimg__text__title">{{ item.text }}</span></router-link> 
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  
  
  export default {
    name: 'MainProject',
    data() {
    return {
      items: [
        { id: 1, image: './img/s41/Image5.png', text: 'Минималистичная спальня', tag: 'Спальня' },
        { id: 2, image: './img/s41/Image2.png', text: 'Минималистичная спальня', tag: 'Спальня' },
        { id: 3, image: './img/s41/Image2.png', text: 'Классическая спальня', tag: 'Спальня' },
        { id: 4, image: './img/s41/Image4.png', text: 'Минималистичная гостиная', tag: 'Гостиная' },
        { id: 5, image: './img/s41/Image5.png', text: 'Минималистичная гостиная', tag: 'Гостиная' },
        { id: 6, image: './img/s41/Image6.png', text: 'Классическая гостиная', tag: 'Гостиная' },
        { id: 7, image: './img/s41/Image7.png', text: 'Минималистичная кухня', tag: 'Кухня' },
        { id: 8, image: './img/s41/Image5.png', text: 'Минималистичная кухня', tag: 'Кухня' },
        { id: 9, image: './img/s41/Image2.png', text: 'Классическая кухня', tag: 'Кухня' },
       
      ],
      selectedTag: 'All'
    };
  },
  computed: {
    uniqueTags() {
      const tags = this.items.map(item => item.tag);
      return ['All', ...new Set(tags)];
    },
    filteredItems() {
      if (this.selectedTag === 'All') {
        return this.items;
      }
      return this.items.filter(item => item.tag === this.selectedTag);
    }
  },
    methods: {
      // goToHome() {
      //   this.$emit('navigate', 'MainPage');
      // },
      // goToDetail() {
      //   this.$emit('navigate', 'ProjectDetails');
      // },
      selectTag(tag) {
      this.selectedTag = tag;
    }
    }
  };
  </script>
 <style scoped lang="scss">
 @import '../assets/filesforstyle/vars';
 a {
  text-decoration: none;
 }
 .tags {
   margin-bottom: 20px;
   @include ParamWHM(none, none, -380px, none, none, none);

 }
 .tags button {
   margin-right: 10px;
   padding: 5px 10px;
   cursor: pointer;
 }
 .tags button.active {
   font-weight: bold;
 }
 .s21container{
  @include ParamWHM($widthS21, $heightS21, none, none, none, none);

}
.s22container{
  @include ParamWHM($widthtotal, 200px, none, none, -220px, none);
  @include ParamPosition(none, flex, center, none);
  &__text{
      @include ParamWHM($widthS22, $heightS22, none, none, none, none);
      @include ParamPosition(none, flex, none, none);
      background-color:$colortotal;
      border-top-left-radius: 10%;
      border-top-right-radius: 10%;
      flex-direction: column;
      align-items: center;
      padding: 0px;
      gap: 12px;
      &__up{
          margin-top: 30px;
          width: 362px;
          text-align: center;
          &__title {
              @include ParamText(#222, Jost, 50px, 400, none, center);   
          } 
      }
}

}
 .s4container {
  @include ParamWHM($widthS4, $heightS4, 330px, none, 10px, none);
  display: grid;
  flex-wrap: wrap;
  justify-content: space-evenly;
  grid-template-columns: repeat(2, 500px);
  grid-auto-flow: dense;
  gap: 20px;
    &__link {
      &__subimg{ 
        @include ParamWHM(400px, 70px, none, none, 24px, 50px);
        @include ParamPosition(none, flex, space-between, none);
        &__text {
          @include ParamText(#292F36, Jost, 22px, 400, none, center);
          &__title{ 
            @include ParamText(#292F36, Jost, 25px, 400, none, center);
          }
        }
       
      }
    }
  
}
 
 </style>