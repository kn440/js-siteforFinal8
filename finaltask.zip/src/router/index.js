import Vue from 'vue';
import Router from 'vue-router';
import MainPage from '@/components/MainPage.vue';
import MainProject from '@/components/MainProject.vue';
import ProjectDetails from '@/components/ProjectDetails.vue';
import NotFound from '@/components/NotFound.vue';

Vue.use(Router)

export default new Router({
  mode:'history',
  routes:[
    { path: '/', component: MainPage },
    { path: '/mainproject', component: MainProject },
    { path: '/projectdetails', component: ProjectDetails },
    { path: '/404', component: NotFound },
    {path: '*', redirect:'/404'},
]})


